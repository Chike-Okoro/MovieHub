package com.example.starmoviehub

data class MovieList(
    var movieImage: Int,
    var starImage: Int,
    var movieName: String,
    var genre: String,
    var period: String,
    var rating: String
)