package com.example.myfirstproject.module

import org.koin.dsl.module


val sharedclassmodule = module {

//    single { PaperPrefs(androidApplication()) }

}
