package com.example.starmoviehub.repository


import com.example.myfirstproject.network.MyFirstProjectApi
import com.example.myfirstproject.repository.BaseRepository
import com.example.myfirstproject.utils.UseCaseResult
import com.example.starmoviehub.model.request.GetPopularMoviesRequest
import com.example.starmoviehub.model.response.GetPopularMoviesResponse

interface MovieRepository {
    suspend fun getPopularMovies(request: GetPopularMoviesRequest): UseCaseResult<GetPopularMoviesResponse>
}

class MovieRepositoryImpl(private val movieApi: MyFirstProjectApi): BaseRepository(), MovieRepository{
    override suspend fun getPopularMovies(request: GetPopularMoviesRequest): UseCaseResult<GetPopularMoviesResponse> {
        val apiRequest = movieApi.getPopularMovies(request.apiKey)
        return safeGetApiCall(apiRequest) { it.status_code == null && it.status_message == null }
    }

}