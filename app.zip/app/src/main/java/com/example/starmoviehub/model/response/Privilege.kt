package com.example.myfirstproject.model.response

data class Privilege(
    val id: String,
    val privilegename: String,
    val showmenu: Boolean
)