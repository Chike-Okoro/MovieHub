package com.example.starmoviehub.model.request

data class GetPopularMoviesRequest(
    val apiKey: String
)