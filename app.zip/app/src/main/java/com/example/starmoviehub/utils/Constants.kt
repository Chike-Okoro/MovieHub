package com.example.myfirstproject.utils

object Constants {
    val SOURCE = "MOBILE"
    val UPLOAD_URL = "https://rubies-s3-b64-image-upload.herokuapp.com/upload"
    val NAIRA = "₦"
    val DOLLAR = "$"
    val DOLLARWORD = "USD"
    val SUCCESS_CODE = "00"
    val DEFAULT_ERROR_MSG = "Something went wrong"
    val MY_SCAN_REQUEST_CODE = 23
    val BUCKETNAME = "apvertise-image-bucket"
    val BUCKETURL = "https://s3.us-east-1.amazonaws.com/apvertise-image-bucket/"
    val DOLLARCODE ="USD"
}